import{g as r}from"./chunk-NMDLJX5Q.js";var s=()=>{let e;return{lock:()=>r(null,null,function*(){let o=e,t;return e=new Promise(n=>t=n),o!==void 0&&(yield o),t})}};export{s as a};
