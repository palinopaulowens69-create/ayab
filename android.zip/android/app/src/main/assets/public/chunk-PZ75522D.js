import{b as a,c as b}from"./chunk-WH2HIQK6.js";import"./chunk-NMDLJX5Q.js";export{a as GESTURE_CONTROLLER,b as createGesture};
